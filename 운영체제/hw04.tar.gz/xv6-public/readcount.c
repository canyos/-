#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
    int count = getreadcount();
    printf(1, "%d\n",count);
    exit();
}
